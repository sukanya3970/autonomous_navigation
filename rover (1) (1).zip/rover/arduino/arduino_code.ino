// ============================================================================
// ROBO 1.0 - Feed-forward + PI wheel-speed controller (Arduino Mega 2560)
// ============================================================================

// Wire provides I2C communication used by the BNO055 IMU.
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>

// Set to 1 temporarily when tuning the wheel controller. Debug rows begin with T, and are separate from D, sensor telemetry.
#define DEBUG_PID 0   // 1 = print "T,..." lines for tuning feedback

// ---------------------------------------------------------------- constants
// Motion-model calibration: counts per encoder/motor revolution as expected by this implementation. Confirm whether this value already includes quadrature decoding.
const float ENCODER_CPR = 4096.0; 
// The gearbox ratio converts motor revolutions to wheel revolutions; it is multiplied by ENCODER_CPR below.
const float GEAR_RATIO  = 3.6;    
const float WHEEL_CIRC  = 0.32;   // Metres travelled by the wheel in one full revolution; calibrate for the actual wheel.
const float TRACK_WIDTH = 0.55;   // Effective distance between the left and right drive wheels, in metres.
// Largest allowed magnitude of either wheel target. This prevents a turn command from asking one wheel to exceed the configured limit.
const float MAX_VEL     = 0.50;   // Max linear speed per wheel in m/s

// PWM is constrained to this range even if PID correction requests more output. Arduino PWM values normally range from 0 to 255.
const int MAX_PWM = 180;          
// Minimum non-zero drive magnitude used after a target clears the deadband; low PWM can be insufficient to overcome static friction.
const int MIN_PWM = 30;           // Absolute minimum PWM to overcome stiction once moving

// PI gains. The controller correction is added to the calibrated feed-forward PWM.
// Kp responds to current speed error; Ki corrects persistent speed bias over time.
// These are starting values and must be verified on the actual rover under safe conditions.
const float PID_KP = 80.0;
const float PID_KI = 20.0;
// Bounds the accumulated velocity error (integral state) and therefore bounds the integral contribution.
const float PID_INTEGRAL_LIMIT   = 0.5;
// Limits how much the PI controller may add to or subtract from feed-forward PWM.
const float PID_CORRECTION_LIMIT = 50.0;

// Run wheel-speed feedback every 50 ms (20 Hz); dt is computed from actual elapsed time for the speed calculation.
const unsigned long PID_INTERVAL_MS        = 50;  
// Emit one sensor telemetry row at most every 20 ms (50 Hz). Serial bandwidth can affect this rate.
const unsigned long TELEMETRY_INTERVAL_MS = 20;  
// Read IMU data every 50 ms when the sensor was detected successfully.
const unsigned long IMU_INTERVAL_MS        = 50;  
// If no valid motion command refreshes this timer for 1 s, both wheel targets are set to zero as a communication failsafe.
const unsigned long CMD_TIMEOUT_MS        = 1000;  

// Mounting/coordinate convention adjustments applied to the BNO055 yaw before it is zeroed.
// These settings do not affect motor control in this sketch; they only affect reported IMU orientation.
const float IMU_YAW_OFFSET = 180.0;
const float IMU_YAW_SIGN   = 1.0;

// ------------------------------------------------------------------- motors
// Keep the pins and direction convention for each driver channel together in one record. inverted compensates for a motor mounted/wired in the opposite orientation.
struct Motor { uint8_t ren, len, rpwm, lpwm; bool inverted; };

// Rear-left motor driver: enable pins 26/27 and direction-PWM pins 6/7. Do not change without matching the physical wiring.
const Motor LEFT_MOTOR  = {26,27,6,7, false};   
// Rear-right motor driver: enable pins 28/29 and direction-PWM pins 10/11. inverted=true reverses the PWM-side choice for this wheel.
const Motor RIGHT_MOTOR = {28,29,10,11, true};   

// Legacy front-driver pins: setup configures these as outputs held LOW so the removed front channels stay inactive. This sketch does not command front motors.
const uint8_t FRONT_PINS[] = {2, 3, 4, 5, 22, 23, 24, 25};

// Per-wheel control state. target is requested wheel velocity; measured is encoder-derived velocity; integral and pwm hold controller state.
struct Wheel
{
    const Motor *motor; // Which physical motor output this wheel controller commands.
    float target;      // Requested wheel linear velocity in m/s; sign determines direction.
    float measured;    // Actual wheel linear velocity in m/s, calculated from encoder ticks.
    float integral;    // Bounded accumulated speed error; multiplied by PID_KI for integral correction.
    long  prevCount;   // Encoder count saved from the previous PID update.
    int   pwm;         // Last signed PWM command sent to the motor driver.
};

// Convert signed wheel PWM into the driver's enable and directional PWM signals. Positive/negative sign selects direction; magnitude selects duty cycle.
void driveMotor(const Motor &m, int pwm)
{
    // Clamp signed PWM first so no downstream command exceeds the allowed motor-drive limit.
    pwm = constrain(pwm, -MAX_PWM, MAX_PWM);

    // Keep both driver enable inputs asserted. The exact meaning of these signals depends on the installed H-bridge driver.
    digitalWrite(m.ren, HIGH); 
    digitalWrite(m.len, HIGH);

    // A zero command sets both PWM inputs to zero. This is the sketch’s stop behavior; it does not actively reverse the motor to brake.
    if (pwm == 0)   
    {
        analogWrite(m.rpwm, 0);
        analogWrite(m.lpwm, 0);
        return;
    }

    // XOR-like comparison combines requested direction with each motor’s inversion setting. It lets both wheels report positive velocity for robot-forward travel.
    bool forward = (pwm > 0) != m.inverted;
    analogWrite(m.rpwm, forward ? abs(pwm) : 0);
    analogWrite(m.lpwm, forward ? 0 : abs(pwm));
}

// ----------------------------------------------------------------- encoders
// Encoder sign corrections make forward wheel motion count as positive for both sides, despite mirrored mounting or wiring.
const int LEFT_ENC_SIGN  = -1;
const int RIGHT_ENC_SIGN = +1;

// Quadrature transition lookup table: valid A/B state changes produce +1 or -1; unchanged/invalid transitions contribute zero.
const int8_t quadTable[16] = { 0,-1, 1, 0,  1, 0, 0,-1,  -1, 0, 0, 1,  0, 1,-1, 0 };

// Updated inside an interrupt and read by the main loop. volatile prevents the compiler from assuming these values never change asynchronously.
volatile long leftCount = 0, rightCount = 0;
volatile uint8_t leftPrev = 0, rightPrev = 0;

// Extract one encoder’s two bits from the captured Port K register and pack them as a two-bit quadrature state.
inline uint8_t encState(uint8_t k, uint8_t a, uint8_t b)
{
    return (((k >> a) & 1) << 1) | ((k >> b) & 1);
}

// Port-K pin-change interrupt: runs on encoder A/B transitions, allowing counts to be updated even while the main loop is busy. Keep this routine short.
ISR(PCINT2_vect)
{
    // Read A8–A15 together in one register snapshot; this sketch uses A12/A13 for left and A14/A15 for right.
    uint8_t k = PINK;
    uint8_t l = encState(k, 4, 5);
    uint8_t r = encState(k, 6, 7);

    // Combine the previous and current states into a lookup index to determine transition direction and tick size.
    leftCount  += quadTable[(leftPrev  << 2) | l];
    rightCount += quadTable[(rightPrev << 2) | r];

    leftPrev  = l;
    rightPrev = r;
}

// Copy the volatile count atomically. On an 8-bit AVR, a 32-bit long takes multiple CPU operations and could otherwise be read halfway through an interrupt update.
long readLeftEnc()
{
    // Temporarily disable interrupts only while copying the multi-byte counter, then restore interrupt processing immediately.
    noInterrupts(); long c = leftCount; interrupts();
    return LEFT_ENC_SIGN * c;
}

long readRightEnc()
{
    noInterrupts(); long c = rightCount; interrupts();
    return RIGHT_ENC_SIGN * c;
}

// Configure encoder inputs and enable the Mega 2560 Port-K pin-change interrupt for the four encoder signals.
void setupEncoders()
{
    pinMode(A12, INPUT_PULLUP);
    pinMode(A13, INPUT_PULLUP);
    pinMode(A14, INPUT_PULLUP);
    pinMode(A15, INPUT_PULLUP);

    uint8_t k = PINK;
    leftPrev  = encState(k, 4, 5);
    rightPrev = encState(k, 6, 7);

    PCICR &= ~(1 << PCIE2);
    // Enable pin-change interrupts for the upper four Port-K bits (PK4–PK7, corresponding to A12–A15 on the Mega 2560).
    PCMSK2 = 0xF0;              
    PCIFR |= (1 << PCIF2);
    PCICR |= (1 << PCIE2);
}

// ---------------------------------------------------------- feed-forward table (Starts cleanly at 0.0)
const int FF_POINTS = 22;
// Calibrated feed-forward lookup: each velocity point maps to the PWM that previously produced roughly that speed. These values should come from measured wheel data.
const float ffVelocity[FF_POINTS] = {
    0.000, 0.122, 0.144, 0.183, 0.198, 0.212, 0.215, 0.232, 0.255,
    0.267, 0.278, 0.287, 0.294, 0.301, 0.306, 0.328, 0.330, 
    0.365, 0.399, 0.434, 0.468, 0.500                        
};
// PWM values paired by index with ffVelocity above. Both arrays must remain the same length and in ascending velocity order.
const int ffPWM[FF_POINTS] = {
    0, 30, 32, 34, 36, 38, 40, 42, 44,
    46, 48, 50, 52, 54, 56, 58, 60, 
    65, 70, 75, 80, 85              
};

// Estimate the PWM needed to reach a requested speed before PID correction. Feed-forward handles most of the motor effort; PID compensates for residual error.
int feedForwardPWM(float vel)
{
    float mag = fabs(vel);

    // FIX: If target speed is extremely small, return 0 PWM instead of forcing MIN_PWM (30)
    // Ignore tiny target speeds to avoid motor chatter caused by noise or an impractically small command. This establishes a 0.02 m/s deadband.
    if (mag < 0.02) 
        return 0;

    if (mag >= ffVelocity[FF_POINTS - 1])   
        return ffPWM[FF_POINTS - 1];

    for (int i = 0; i < FF_POINTS - 1; i++)
    {
        if (mag <= ffVelocity[i + 1])
        {
            // Linearly interpolate between the two calibration points around the requested speed rather than jumping to a table value.
            float ratio = (mag - ffVelocity[i]) / (ffVelocity[i + 1] - ffVelocity[i]);
            return (int)round(ffPWM[i] + ratio * (ffPWM[i + 1] - ffPWM[i]));
        }
    }
    return 0;
}

// ----------------------------------------------------------------- wheel PI
// Create independent controller state for each driven wheel; each state points at its own motor pin configuration.
Wheel leftWheel  = {&LEFT_MOTOR,  0, 0, 0, 0, 0};
Wheel rightWheel = {&RIGHT_MOTOR, 0, 0, 0, 0, 0};

// Return +1 for positive, -1 for negative, and 0 for zero. Used to preserve commanded direction after calculating PWM magnitude.
int signOf(float x) { return (x > 0) - (x < 0); }

// One wheel's control step: feed-forward supplies the nominal PWM, then PI feedback trims it.
// The error is measured in the direction requested by the target so forward and reverse use the same controller logic.
void updateWheel(Wheel &w, float dt)
{
    // An effectively zero target is a real stop: clear stored integral and command zero output.
    if (fabs(w.target) < 0.001)
    {
        w.integral = 0;
        w.pwm = 0;
        driveMotor(*w.motor, 0);
        return;
    }

    // Feed-forward maps the requested speed magnitude to the nominal PWM. Values in its deadband return zero.
    const float targetSpeed = fabs(w.target);
    const int basePWM = feedForwardPWM(targetSpeed);
    if (basePWM == 0 || dt <= 0.0f)
    {
        // There is no useful actuation in the deadband, so don't preserve stale integral for a later command.
        w.integral = 0;
        w.pwm = 0;
        driveMotor(*w.motor, 0);
        return;
    }

    // Project signed encoder velocity onto the requested direction. Correct encoder polarity makes this positive
    // while the wheel moves as commanded, for both forward and reverse travel.
    const float measuredAlongTarget = signOf(w.target) * w.measured;
    const float error = targetSpeed - measuredAlongTarget;

    // Propose an integral update: I[k] = clamp(I[k-1] + error * dt, -I_limit, +I_limit).
    // Conditional integration below rejects updates that would drive an already-saturated output further into saturation.
    const float candidateIntegral = constrain(w.integral + error * dt,
                                              -PID_INTEGRAL_LIMIT, PID_INTEGRAL_LIMIT);
    const float candidateRawCorrection = PID_KP * error + PID_KI * candidateIntegral;
    const float candidateCorrection = constrain(candidateRawCorrection,
                                                -PID_CORRECTION_LIMIT, PID_CORRECTION_LIMIT);
    const float candidateMagnitude = basePWM + candidateCorrection;

    const bool upperSaturated = (candidateRawCorrection > PID_CORRECTION_LIMIT) ||
                                (candidateMagnitude > MAX_PWM);
    const bool lowerSaturated = (candidateRawCorrection < -PID_CORRECTION_LIMIT) ||
                                (candidateMagnitude < MIN_PWM);
    const bool pushesFurtherIntoSaturation =
        (upperSaturated && error > 0.0f) || (lowerSaturated && error < 0.0f);

    // Anti-windup: accept the proposed integral only when it does not push the output farther into a limit.
    if (!pushesFurtherIntoSaturation)
        w.integral = candidateIntegral;

    // PI correction = Kp * current error + Ki * accumulated error, bounded in PWM units.
    const float correction = constrain(PID_KP * error + PID_KI * w.integral,
                                       -PID_CORRECTION_LIMIT, PID_CORRECTION_LIMIT);

    // Add feedback to the feed-forward baseline and clamp the final PWM magnitude to the configured motor limits.
    int magnitude = basePWM + (int)round(correction);
    magnitude = constrain(magnitude, MIN_PWM, MAX_PWM);

    // Apply the requested sign only after magnitude control; driveMotor() maps it to the wired direction pins.
    w.pwm = signOf(w.target) * magnitude;
    driveMotor(*w.motor, w.pwm);
}

// Run the wheel-speed feedback loop on a fixed schedule, estimate each wheel’s speed from encoder ticks, then update both controllers.
void controlLoop()
{
    static unsigned long lastPID = 0;

    unsigned long now = millis();
    // Keep the control rate predictable; other tasks (serial parsing and telemetry) can run more often between PID updates.
    if (now - lastPID < PID_INTERVAL_MS) return;

    // Convert actual elapsed milliseconds to seconds so the speed calculation remains correct if loop timing varies slightly.
    float dt = (now - lastPID) / 1000.0;
    lastPID = now;

    long l = readLeftEnc();
    long r = readRightEnc();

    // Expected encoder counts for one wheel revolution. This assumes ENCODER_CPR is specified on the motor side and GEAR_RATIO is motor:wheel.
    const float countsPerRev = ENCODER_CPR * GEAR_RATIO;
    // Convert count change -> counts/second -> wheel revolutions/second -> metres/second.
    leftWheel.measured  = ((l - leftWheel.prevCount)  / dt) / countsPerRev * WHEEL_CIRC;
    rightWheel.measured = ((r - rightWheel.prevCount) / dt) / countsPerRev * WHEEL_CIRC;
    leftWheel.prevCount  = l;
    rightWheel.prevCount = r;

    updateWheel(leftWheel,  dt);
    updateWheel(rightWheel, dt);

// Optional PI diagnostics: signed target speed, signed encoder speed, and applied PWM for left then right.
#if DEBUG_PID
    static unsigned long lastDebug = 0;
    if (now - lastDebug >= 100)
    {
        lastDebug = now;
        Serial.print("T,");
        Serial.print(leftWheel.target, 3);  Serial.print(",");
        Serial.print(leftWheel.measured, 3); Serial.print(",");
        Serial.print(leftWheel.pwm);         Serial.print(",");
        Serial.print(rightWheel.target, 3); Serial.print(",");
        Serial.print(rightWheel.measured, 3); Serial.print(",");
        Serial.println(rightWheel.pwm);
    }
#endif
}

// ------------------------------------------------------------------ cmd_vel
unsigned long lastCmdTime = 0;

// Store a new target. Clear integral memory when direction changes so old forward error does not affect reverse output (and vice versa).
void setWheelTarget(Wheel &w, float t)
{
    if (signOf(t) != signOf(w.target)) w.integral = 0;   
    w.target = t;
}

// Convert robot-level linear velocity v (m/s) and angular velocity w (rad/s) into independent left/right wheel targets for differential drive.
void setCmdVel(float v, float w)
{
    lastCmdTime = millis(); 

    // Differential-drive kinematics: a positive yaw command slows the left wheel and speeds the right wheel for the usual ROS convention.
    float left  = v - w * TRACK_WIDTH * 0.5;
    float right = v + w * TRACK_WIDTH * 0.5;

    // If either wheel would exceed MAX_VEL, scale both targets by the same ratio so the requested curvature is preserved.
    float maxMag = max(fabs(left), fabs(right));
    if (maxMag > MAX_VEL)
    {
        left  *= MAX_VEL / maxMag;
        right *= MAX_VEL / maxMag;
    }

    setWheelTarget(leftWheel,  left);
    setWheelTarget(rightWheel, right);
}

// ---------------------------------------------------------------------- IMU
// BNO055 instance at I2C address 0x28. The ID parameter is a library identifier, not an I2C address.
Adafruit_BNO055 bno(55, 0x28);
bool imuOK = false;

float imuYaw = 0, imuPitch = 0, imuRoll = 0;
float gyroX = 0, gyroY = 0, gyroZ = 0;
float accelX = 0, accelY = 0, accelZ = 0;

float imuRefYaw = 0;
bool  imuRefSet = false;

// Wrap an angle into (-180, 180] degrees so yaw changes across the 0/360 boundary remain small and continuous.
float normalize180(float a)
{
    while (a > 180.0)   a -= 360.0;
    while (a <= -180.0) a += 360.0;
    return a;
}

// Read orientation, angular velocity, and linear acceleration from the BNO055. The resulting values are reported in telemetry.
void readIMU()
{
    sensors_event_t ori, gyro, accel;
    bno.getEvent(&ori,   Adafruit_BNO055::VECTOR_EULER);
    bno.getEvent(&gyro,  Adafruit_BNO055::VECTOR_GYROSCOPE);
    bno.getEvent(&accel, Adafruit_BNO055::VECTOR_LINEARACCEL);

    // Apply the mounting/heading offset and sign convention before comparing yaw to the startup reference. Tune these for sensor mounting.
    float yaw = normalize180(normalize180(ori.orientation.x + IMU_YAW_OFFSET) * IMU_YAW_SIGN);

    // The first valid reading becomes zero heading. imuYaw then reports rotation relative to the direction the robot faced at startup.
    if (!imuRefSet) { imuRefYaw = yaw; imuRefSet = true; }

    imuYaw   = normalize180(yaw - imuRefYaw);
    imuPitch = ori.orientation.y;
    imuRoll  = ori.orientation.z;

    gyroX = gyro.gyro.x;   gyroY = gyro.gyro.y;   gyroZ = gyro.gyro.z;
    accelX = accel.acceleration.x;
    accelY = accel.acceleration.y;
    accelZ = accel.acceleration.z;
}

// ---------------------------------------------------------------- telemetry
// Send sensor data in the existing comma-separated D, format so the host-side telemetry decoder can continue parsing it.
void sendTelemetry()
{
    static unsigned long last = 0;
    unsigned long now = millis();
    if (now - last < TELEMETRY_INTERVAL_MS) return;
    last = now;

    // Field order: D,timestamp_ms,left_ticks,right_ticks,yaw,pitch,roll,gyro_x,gyro_y,gyro_z,accel_x,accel_y,accel_z. Keep this order compatible with the host parser.
    Serial.print("D,");
    Serial.print(now);            Serial.print(",");
    Serial.print(readLeftEnc());  Serial.print(",");
    Serial.print(readRightEnc()); Serial.print(",");
    Serial.print(imuYaw, 2);      Serial.print(",");
    Serial.print(imuPitch, 2);    Serial.print(",");
    Serial.print(imuRoll, 2);     Serial.print(",");
    Serial.print(gyroX, 4);       Serial.print(",");
    Serial.print(gyroY, 4);       Serial.print(",");
    Serial.print(gyroZ, 4);       Serial.print(",");
    Serial.print(accelX, 4);      Serial.print(",");
    Serial.print(accelY, 4);      Serial.print(",");
    Serial.println(accelZ, 4);
}

// ----------------------------------------------------------------- commands
// Maximum command-line length including room for a null terminator; overly long lines are rejected.
const uint8_t CMD_SIZE = 48;

// Parse one complete newline-terminated command. Supported commands: V <linear_m_s> <angular_rad_s> and S (stop).
void handleCommand(char *c)
{
    while (*c == ' ' || *c == '\t') c++;

    // S provides an explicit stop command by setting both body velocities to zero.
    if (c[0] == 'S' || c[0] == 's')          
    {
        setCmdVel(0, 0);
        return;
    }

    // V parses the ROS-style body velocity pair: linear velocity followed by angular velocity. strtod accepts whitespace between numbers.
    if (c[0] == 'V' || c[0] == 'v')          
    {
        char *e1, *e2;
        float v = strtod(c + 1, &e1);
        float w = strtod(e1, &e2);

        // Reject missing numbers, parse failures, NaN, and infinity; invalid values must never be sent to the motor controller.
        if (e1 == c + 1 || e2 == e1 || !isfinite(v) || !isfinite(w))
        {
            Serial.println("ERR V");
            return;
        }
        setCmdVel(v, w);
    }
}

// Non-blocking serial line reader shared by USB Serial and Serial3. It collects characters until CR/LF, then calls handleCommand().
void readPort(Stream &port, char *buf, uint8_t &idx, bool &overflow)
{
    while (port.available())
    {
        char c = (char)port.read();

        // Carriage return and newline both terminate a command, accommodating different host terminal settings.
        if (c == '\n' || c == '\r')
        {
            if (overflow)        { overflow = false; idx = 0; Serial.println("ERR TOO LONG"); }
            else if (idx > 0)    { buf[idx] = '\0'; handleCommand(buf); idx = 0; }
            continue;
        }

        if (c < 32 || c > 126 || overflow) continue;

        // Reserve one byte for the string terminator; once full, mark overflow and discard characters until line ending.
        if (idx < CMD_SIZE - 1) buf[idx++] = c;
        else                    overflow = true;
    }
}

// Separate receive buffers are essential: bytes from Serial and Serial3 must not be mixed into one command.
char usbBuf[CMD_SIZE], s3Buf[CMD_SIZE];
uint8_t usbIdx = 0, s3Idx = 0; // Number of characters currently collected on each port.
bool usbOver = false, s3Over = false; // Set when a line exceeds CMD_SIZE; clear at its line ending.

// -------------------------------------------------------------- setup / loop
// Hardware initialization happens once at boot: serial links, safe output levels, encoders, I2C/IMU, and initial controller state.
void setup()
{
    // USB serial is used for host commands, status messages, and sensor telemetry.
    Serial.begin(115200);
    // Hardware UART 3 is an alternative command input (e.g. an external controller). Match its baud rate on the connected device.
    Serial3.begin(9600);

    // Keep legacy front-driver pins configured LOW. The control loop below only drives LEFT_MOTOR and RIGHT_MOTOR.
    for (uint8_t i = 0; i < sizeof(FRONT_PINS); i++)
    {
        pinMode(FRONT_PINS[i], OUTPUT);
        digitalWrite(FRONT_PINS[i], LOW);
    }

    // Use the same initialization routine for the two rear motor channels to avoid mismatched pin setup.
    const Motor *motors[] = {&LEFT_MOTOR, &RIGHT_MOTOR};
    for (uint8_t i = 0; i < 2; i++)
    {
        pinMode(motors[i]->ren,  OUTPUT);
        pinMode(motors[i]->len,  OUTPUT);
        pinMode(motors[i]->rpwm, OUTPUT);
        pinMode(motors[i]->lpwm, OUTPUT);
        driveMotor(*motors[i], 0);
    }

    // Configure A12–A15 as encoder inputs and enable the change interrupts that maintain the tick counts.
    setupEncoders();

    Wire.begin();
    // Use 400 kHz I2C if supported by the sensor and wiring; shorter transfers reduce time spent reading the IMU.
    Wire.setClock(400000UL);   

    // Detect the IMU before attempting regular reads. If detection fails, telemetry remains available but IMU values stay at their defaults.
    imuOK = bno.begin();
    if (imuOK)
    {
        delay(1000);
        bno.setExtCrystalUse(true);
        readIMU();
    }

    // Seed previous counts before the first velocity calculation so startup ticks are not mistaken for one control interval of motion.
    leftWheel.prevCount  = readLeftEnc();
    rightWheel.prevCount = readRightEnc();
    lastCmdTime = millis();

    Serial.println(imuOK ? "BNO055 OK" : "BNO055 ERROR");
    Serial.println("READY");
}

// Main scheduler: receive commands, refresh IMU, enforce command timeout, run wheel PI control, and stream telemetry.
void loop()
{
    // Poll both input ports without blocking so a command on either interface can refresh the motor targets.
    readPort(Serial,  usbBuf, usbIdx, usbOver);
    readPort(Serial3, s3Buf,  s3Idx,  s3Over);

    static unsigned long lastIMU = 0;
    unsigned long now = millis();

    // Do not attempt I2C sensor reads if the BNO055 did not initialize; rate-limit reads to IMU_INTERVAL_MS.
    if (imuOK && now - lastIMU >= IMU_INTERVAL_MS)
    {
        lastIMU = now;
        readIMU();
    }

    // Command watchdog: if commands stop arriving, set targets to zero. The PID loop then writes zero drive to each wheel.
    if (now - lastCmdTime > CMD_TIMEOUT_MS)
    {
        setWheelTarget(leftWheel,  0);
        setWheelTarget(rightWheel, 0);
    }

    // Run feedback control after processing commands so the newest targets are used. The function self-schedules at 20 Hz.
    controlLoop();
    // Send sensor values independently of the slower wheel PI cadence.
    sendTelemetry();
}