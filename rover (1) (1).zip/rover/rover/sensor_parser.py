#!/usr/bin/env python3

import math
from typing import Optional

import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from sensor_msgs.msg import Imu
from nav_msgs.msg import Odometry


# ============================================================
# ROBOT CONSTANTS
# ============================================================

ENCODER_CPR = 4096.0
GEAR_RATIO = 3.6
WHEEL_CIRC = 0.32       # Arduino WHEEL_CIRC
TRACK_WIDTH = 0.55      # Arduino TRACK_WIDTH
COUNTS_PER_WHEEL_REV = ENCODER_CPR * GEAR_RATIO


def euler_to_quaternion(roll: float, pitch: float, yaw: float):
    """Convert roll/pitch/yaw in radians to quaternion."""
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)

    qw = cr * cp * cy + sr * sp * sy
    qx = sr * cp * cy - cr * sp * sy
    qy = cr * sp * cy + sr * cp * sy
    qz = cr * cp * sy - sr * sp * cy

    return qx, qy, qz, qw


class SensorParser(Node):
    """Convert Arduino D telemetry into ROS Imu and Odometry messages."""

    def __init__(self):
        super().__init__("sensor_parser")

        # ========================================================
        # PARAMETERS
        # ========================================================
        self.declare_parameter("imu_frame", "imu_link")
        self.declare_parameter("odom_frame", "odom")
        self.declare_parameter("base_frame", "base_link")
        self.declare_parameter("gyro_std", 0.001337537)
        self.declare_parameter("accel_std", 0.10)

        self.imu_frame = str(self.get_parameter("imu_frame").value)
        self.odom_frame = str(self.get_parameter("odom_frame").value)
        self.base_frame = str(self.get_parameter("base_frame").value)
        self.gyro_std = float(self.get_parameter("gyro_std").value)
        self.accel_std = float(self.get_parameter("accel_std").value)

        # ========================================================
        # ROS INTERFACES
        # ========================================================
        self.create_subscription(String, "/raw_serial", self.raw_callback, 50)
        self.imu_pub = self.create_publisher(Imu, "/imu/data", 20)
        self.odom_pub = self.create_publisher(Odometry, "/wheel_odom", 20)

        # ========================================================
        # STATE VARIABLES
        # ========================================================
        self.previous_lr_count: Optional[int] = None
        self.previous_rr_count: Optional[int] = None
        self.previous_arduino_ms: Optional[int] = None

        self.odom_x = 0.0
        self.odom_y = 0.0
        self.odom_yaw = 0.0

        self.get_logger().info("Sensor parser node initialized successfully.")

    def now_msg(self):
        return self.get_clock().now().to_msg()

    def raw_callback(self, msg: String):
        line = msg.data.strip()
        if not line:
            return

        parts = [p.strip() for p in line.split(",")]
        try:
            if parts[0] == "D":
                self.parse_telemetry(parts, line)
        except (ValueError, IndexError) as exc:
            self.get_logger().warning(f"Failed to parse serial line: {line} ({exc})")

    def parse_telemetry(self, parts, line):
        if len(parts) < 12:
            self.get_logger().warning(f"D telemetry has too few fields: {len(parts)}")
            return

        try:
            arduino_ms = int(float(parts[1]))
            lr_count = int(float(parts[2]))
            rr_count = int(float(parts[3]))
            yaw_deg = float(parts[4])
            pitch_deg = float(parts[5])

            # Dynamic check: handle both 13-field (with roll) and 12-field formats
            if len(parts) >= 13:
                roll_deg = float(parts[6])
                gyro_x = float(parts[7])
                gyro_y = float(parts[8])
                gyro_z = float(parts[9])
                accel_x = float(parts[10])
                accel_y = float(parts[11])
                accel_z = float(parts[12])
            else:
                roll_deg = 0.0
                gyro_x = float(parts[6])
                gyro_y = float(parts[7])
                gyro_z = float(parts[8])
                accel_x = float(parts[9])
                accel_y = float(parts[10])
                accel_z = float(parts[11])

        except (ValueError, IndexError) as exc:
            self.get_logger().warning(f"Failed to parse fields in line: {line} ({exc})")
            return

        self.publish_imu(yaw_deg, pitch_deg, roll_deg, gyro_x, gyro_y, gyro_z, accel_x, accel_y, accel_z)
        self.update_wheel_odometry(arduino_ms, lr_count, rr_count)

    def publish_imu(self, yaw_deg, pitch_deg, roll_deg, gyro_x, gyro_y, gyro_z, accel_x, accel_y, accel_z):
        yaw = math.radians(yaw_deg)
        pitch = math.radians(pitch_deg)
        roll = math.radians(roll_deg)
        qx, qy, qz, qw = euler_to_quaternion(roll, pitch, yaw)

        imu = Imu()
        imu.header.stamp = self.now_msg()
        imu.header.frame_id = self.imu_frame

        imu.orientation.x = qx
        imu.orientation.y = qy
        imu.orientation.z = qz
        imu.orientation.w = qw
        imu.orientation_covariance[0] = -1.0  # Orientation not directly measured by gyro alone

        imu.angular_velocity.x = gyro_x
        imu.angular_velocity.y = gyro_y
        imu.angular_velocity.z = gyro_z

        gyro_var = max(self.gyro_std ** 2, 1e-12)
        imu.angular_velocity_covariance[0] = gyro_var
        imu.angular_velocity_covariance[4] = gyro_var
        imu.angular_velocity_covariance[8] = gyro_var

        imu.linear_acceleration.x = accel_x
        imu.linear_acceleration.y = accel_y
        imu.linear_acceleration.z = accel_z

        accel_var = max(self.accel_std ** 2, 1e-12)
        imu.linear_acceleration_covariance[0] = accel_var
        imu.linear_acceleration_covariance[4] = accel_var
        imu.linear_acceleration_covariance[8] = accel_var

        self.imu_pub.publish(imu)

    def update_wheel_odometry(self, arduino_ms: int, lr_count: int, rr_count: int):
        if self.previous_lr_count is None:
            self.previous_lr_count = lr_count
            self.previous_rr_count = rr_count
            self.previous_arduino_ms = arduino_ms
            return

        delta_lr = lr_count - self.previous_lr_count
        delta_rr = rr_count - self.previous_rr_count

        self.previous_lr_count = lr_count
        self.previous_rr_count = rr_count

        dt_ms = (arduino_ms - self.previous_arduino_ms) & 0xFFFFFFFF
        self.previous_arduino_ms = arduino_ms

        if dt_ms <= 0:
            return

        dt = dt_ms / 1000.0
        if dt <= 0.0001 or dt > 1.0:
            return

        meters_per_count = WHEEL_CIRC / COUNTS_PER_WHEEL_REV
        left_distance = delta_lr * meters_per_count
        right_distance = delta_rr * meters_per_count

        center_distance = (left_distance + right_distance) * 0.5
        delta_yaw = (right_distance - left_distance) / TRACK_WIDTH

        midpoint_yaw = self.odom_yaw + delta_yaw * 0.5
        self.odom_x += center_distance * math.cos(midpoint_yaw)
        self.odom_y += center_distance * math.sin(midpoint_yaw)
        self.odom_yaw = self.normalize_angle(self.odom_yaw + delta_yaw)

        linear_velocity = center_distance / dt
        angular_velocity = delta_yaw / dt

        self.publish_odometry(linear_velocity, angular_velocity)

    def publish_odometry(self, linear_velocity, angular_velocity):
        odom = Odometry()
        odom.header.stamp = self.now_msg()
        odom.header.frame_id = self.odom_frame
        odom.child_frame_id = self.base_frame

        odom.pose.pose.position.x = self.odom_x
        odom.pose.pose.position.y = self.odom_y
        odom.pose.pose.position.z = 0.0

        qx, qy, qz, qw = euler_to_quaternion(0.0, 0.0, self.odom_yaw)
        odom.pose.pose.orientation.x = qx
        odom.pose.pose.orientation.y = qy
        odom.pose.pose.orientation.z = qz
        odom.pose.pose.orientation.w = qw

        odom.twist.twist.linear.x = linear_velocity
        odom.twist.twist.angular.z = angular_velocity

        # Covariances
        pos_std = 0.05
        yaw_std = math.radians(10.0)
        vel_std = 0.05

        odom.pose.covariance[0] = pos_std ** 2
        odom.pose.covariance[7] = pos_std ** 2
        odom.pose.covariance[14] = 99999.0
        odom.pose.covariance[21] = 99999.0
        odom.pose.covariance[28] = 99999.0
        odom.pose.covariance[35] = yaw_std ** 2

        odom.twist.covariance[0] = vel_std ** 2
        odom.twist.covariance[35] = yaw_std ** 2

        self.odom_pub.publish(odom)

    @staticmethod
    def normalize_angle(angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle <= -math.pi:
            angle += 2.0 * math.pi
        return angle


def main(args=None):
    rclpy.init(args=args)
    node = SensorParser()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()