#!/usr/bin/env python3

import sys
import math
import yaml
import rclpy
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult

def euler_to_quaternion(yaw):
    """Converts a heading angle (yaw in radians) to a ROS 2 Quaternion."""
    return {
        'x': 0.0,
        'y': 0.0,
        'z': math.sin(yaw / 2.0),
        'w': math.cos(yaw / 2.0)
    }

def main():
    rclpy.init()

    if len(sys.argv) < 2:
        print("Usage: ros2 run <your_package> semantic_navigator <location_name>")
        print("Available targets: door_1, table_front, table_right, table_back, table_left, charging_station")
        sys.exit(1)

    target_name = sys.argv[1]

    # Load semantic map config
# Change this:
# yaml_path = "/home/jay/ros2_ws/src/rover/config/semantic_locations.yaml"

# To this:
    yaml_path = "/home/arphaan/ros2_ws/src/rover/config/semantic_locations_lab_part1.yaml"
    with open(yaml_path, 'r') as file:
        locations = yaml.safe_load(file)['locations']

    if target_name not in locations:
        print(f"Error: Location '{target_name}' not recognized in semantic map!")
        sys.exit(1)

    target = locations[target_name]

    # Initialize Nav2 Simple Commander
    navigator = BasicNavigator()

    # Define target pose in 'map' frame
    goal_pose = PoseStamped()
    goal_pose.header.frame_id = 'map'
    goal_pose.header.stamp = navigator.get_clock().now().to_msg()
    goal_pose.pose.position.x = target['x']
    goal_pose.pose.position.y = target['y']

    q = euler_to_quaternion(target['yaw'])
    goal_pose.pose.orientation.z = q['z']
    goal_pose.pose.orientation.w = q['w']

    print(f"Navigating to semantic goal: '{target_name}' at ({target['x']}, {target['y']})...")
    navigator.goToPose(goal_pose)

    while not navigator.isTaskComplete():
        feedback = navigator.getFeedback()
        # Optional: Print progress updates here

    result = navigator.getResult()
    if result == TaskResult.SUCCEEDED:
        print(f"Successfully arrived at {target_name}!")
    elif result == TaskResult.CANCELED:
        print(f"Navigation to {target_name} was canceled.")
    elif result == TaskResult.FAILED:
        print(f"Failed to reach {target_name}.")

    rclpy.shutdown()

if __name__ == '__main__':
    main()